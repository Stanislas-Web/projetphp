<?php
	include_once('classes/Inscriptions.class.php');
	include_once('classes/Connexions.class.php');
	//include_once('classes/Societes.class.php');
	include_once('classes/Produits.class.php');
	
?>