<?php
	session_start();
	unset($_GET['identifiant'])
?>
<script>document.location.replace("index.php");</script>