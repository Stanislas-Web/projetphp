<?php
	//$inscription = new Inscriptions();
	//$connexion = new Connexions();
	//$societe = new Societes();
	$produit = new Produits();
	$panier = new Panier();
	$DB = new DB();
?>